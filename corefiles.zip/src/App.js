import React from 'react';
import './App.css';
import GoogleMapContainer from './Components/GoogleMapContainer/GoogleMapContainer';

function App() {
  return (
    <GoogleMapContainer/>
  );
}

export default App;
